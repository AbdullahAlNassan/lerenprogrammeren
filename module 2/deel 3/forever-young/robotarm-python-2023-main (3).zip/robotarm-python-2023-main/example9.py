from RobotArm import RobotArm

# robotArm = RobotArm('exercise 9')




# robotArm.wait()




robotArm = RobotArm('exercise 9')



# robotArm.grab()
# for _ in range(5): robotArm.moveRight() 
# robotArm.drop()
# for _ in range(4): robotArm.moveLeft()
# robotArm.grab()
# for _ in range(5): robotArm.moveRight()
# robotArm.drop()
# for _ in range(5): robotArm.moveLeft()
# robotArm.grab()
# for _ in range(5): robotArm.moveRight()
# robotArm.drop()
# for _ in range(4): robotArm.moveLeft()
# robotArm.grab()
# for _ in range(5): robotArm.moveRight()
# robotArm.drop()
# for _ in range(5): robotArm.moveLeft()
# robotArm.grab()
# for _ in range(5): robotArm.moveRight()
# robotArm.drop()
# for _ in range(5): robotArm.moveLeft()
# robotArm.grab()
# for _ in range(5): robotArm.moveRight()
# robotArm.drop()
# for _ in range(4): robotArm.moveLeft()
# robotArm.grab()
# for _ in range(5): robotArm.moveRight()
# robotArm.drop()
# for _ in range(5): robotArm.moveLeft()
# robotArm.grab()
# for _ in range(5): robotArm.moveRight()
# robotArm.drop()
# for _ in range(5): robotArm.moveLeft()
# robotArm.grab()
# for _ in range(5): robotArm.moveRight()
# robotArm.drop()
# for _ in range(5): robotArm.moveLeft()
# robotArm.grab()
# for _ in range(5): robotArm.moveRight()
# robotArm.drop()

# # Na jouw code wachten tot het sluiten van de window:
# robotArm.wait()



robotArm.wait()